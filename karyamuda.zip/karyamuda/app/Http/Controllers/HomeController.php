<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Berita;
use App\ViewUser;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $users = ViewUser::all();
        if ($request['region']) {
            if ($request['region'] == 'Komunitas') {
                if (Auth::user()->status == 'Komunitas') {
                    if ($request['kategori']) {
                        $data = Berita::where('id_user','=',Auth::user()->id)->where('kategori','=',$request->kategori)->orderBy('tanggal','desc')->get();
                    }else{
                        $data = Berita::where('id_user','=',Auth::user()->id)->orderBy('tanggal','desc')->get();
                    }
                }else{
                    $data = Berita::where('id_user','=',Auth::user()->id_komunitas)->get();
                }
            }else{
                if (Auth::user()->status == 'Komunitas') {
                    if ($request['kategori']) {
                        $data = Berita::where('kategori','=',$request->kategori)->orderBy('tanggal','desc')->get();
                    }else{
                        $data = Berita::orderBy('tanggal','desc')->get();
                    }
                }else{
                    $data = Berita::orderBy('tanggal','desc')->get();
                }
            }
        }else{
            if ($request['kategori']) {
                $data = Berita::where('kategori','=',$request->kategori)->orderBy('tanggal','desc')->get();
            }else{
                $data = Berita::orderBy('tanggal','desc')->get();
            }
        }
        return view('mahasiswa.home',compact('data','users'));
    }

    public function melengkapi(){
        return view('mahasiswa.melengkapi');
    }


}
