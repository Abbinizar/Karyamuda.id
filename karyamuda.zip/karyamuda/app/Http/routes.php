<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
Route::get('/', function () {
	if (Auth::user()) {
		if (Auth::user()->status == 'Mahasiswa') {
			return redirect('Mahasiswa/home');
		}else{
			return redirect('Komunitas/home');
		}
	}else{
		return view('index');
	}
});
// Route::post('Mahasiswa/Berita/Tambah','BeritaController@store');

Route::get('Mahasiswa/Solusi/Tambah/{id}','SolusiController@index');
Route::post('Mahasiswa/Solusi/{id}/Tambah','SolusiController@store');
Route::get('Mahasiswa/Solusi/Like/{id}','SolusiController@tambahLike');
Route::get('Mahasiswa/Solusi','SolusiController@show');
Route::get('Mahasiswa/Relawan','RelawanController@show');

// Route::get('Mahasiswa/Solusi/Pilih/{id}','SolusiController@pilih');

Route::get('Mahasiswa/Ide','IdeController@index');
Route::post('Mahasiswa/Ide/Tambah','IdeController@store');

Route::get('Mahasiswa/Relawan/{id}/Tambah','RelawanController@index');
Route::get('Mahasiswa/Relawan/Join/{id}','RelawanController@store');

Route::get('Mahasiswa/Profil','UserController@index');
Route::post('Mahasiswa/Update','UserController@update');

Route::get('Mahasiswa/home','HomeController@index');

//----------------------------komunitas
Route::post('Komunitas/Berita/Tambah','BeritaController@store');

Route::get('Komunitas/Solusi/Tambah/{id}','SolusiController@index');
Route::post('Komunitas/Solusi/{id}/Tambah','SolusiController@store');
Route::get('Komunitas/Solusi/Like/{id}','SolusiController@tambahLike');
Route::get('Komunitas/Solusi/Pilih/{id}','SolusiController@pilih');

Route::get('Komunitas/Ide','IdeController@index');
Route::post('Komunitas/Ide/Tambah','IdeController@store');

Route::get('Komunitas/Relawan/{id}/Tambah','RelawanController@index');

Route::get('Komunitas/Profil','UserController@index');
Route::post('Komunitas/Update','UserController@update');

Route::get('Komunitas/Solusi','SolusiController@show');
Route::get('Komunitas/Relawan','RelawanController@show');

Route::get('Mahasiswa/melengkapi','HomeController@melengkapi');
Route::get('Komunitas/home','HomeController@index');
// Route::get('/register','UserController@register');
// Route::get('/Register/Komunitas')

Route::auth();
Route::get('/register','UserController@create');

Route::get('/home', 'HomeController@index');

Route::post('/user/avatar/upload','UserController@avatar');

