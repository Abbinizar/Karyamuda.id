<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','username','nim','jenis_kelamin','id_universitas','id_komunitas','jumlah_solusi','jumlah_relawan','jumlah_ide','status','no_hp','facebook','twitter','instagram','keterangan'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function kota(){
        return $this->belongsTo('App\Kota','id_kota','id_kota');
    }

    public function universitas(){
        return $this->belongsTo('App\Universitas','id_universitas','id_universitas');
    }

    public function komunitas(){
        return $this->belongsTo('App\UserDetail','id_komunitas','id');
    }
}
