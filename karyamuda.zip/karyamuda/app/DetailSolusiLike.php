<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailSolusiLike extends Model
{
    protected $table = 'detail_solusi_like';
    public $timestamps = false;
}
