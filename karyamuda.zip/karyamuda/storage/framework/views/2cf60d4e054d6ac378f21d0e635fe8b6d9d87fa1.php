<?php $__env->startSection('content'); ?>
<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <img style="width: 130px;position: absolute;top: 5px;left: 93px;" src="<?php echo e(url('img/logo-horizontal.png')); ?>">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
    <!-- <a href="#" class="w3-bar-item w3-button w3-padding-large w3-theme-d4"><i class="fa fa-home w3-margin-right"></i></a> -->
  <!--   <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="News"><i class="fa fa-globe"></i></a>
    <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings"><i class="fa fa-user"></i></a>
    <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Messages"><i class="fa fa-envelope"></i></a>
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-button w3-padding-large" title="Notifications"><i class="fa fa-bell"></i><span class="w3-badge w3-right w3-small w3-green">3</span></button>     
      <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
        <a href="#" class="w3-bar-item w3-button">One new friend request</a>
        <a href="#" class="w3-bar-item w3-button">John Doe posted on your wall</a>
        <a href="#" class="w3-bar-item w3-button">Jane likes your post</a>
      </div>
    </div> -->
  <a href="<?php echo e(url('logout')); ?>" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account"><img src="" class="w3-circle" style="height:25px;width:25px" alt="Logout"></a>
  <a href="<?php echo e(url('/')); ?>" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account"><img src="" class="w3-circle" style="height:25px;width:25px" alt="Beranda"></a>
  
</div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="<?php echo e(url('/')); ?>" class="w3-bar-item w3-button w3-padding-large">Beranda</a>

  <a href="<?php echo e(url(Auth::user()->status.'/Solusi')); ?>" class="w3-bar-item w3-button w3-padding-large">Solusi</a>
  <a href="<?php echo e(url(Auth::user()->status.'/Ide')); ?>" class="w3-bar-item w3-button w3-padding-large">IDE</a>
  <a href="<?php echo e(url(Auth::user()->status.'/Relawan')); ?>" class="w3-bar-item w3-button w3-padding-large">Relawan</a>
  <a href="<?php echo e(url('/logout')); ?>" class="w3-bar-item w3-button w3-padding-large">Logout</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">"<?php echo e(Auth::user()->name); ?>"</h4>
         <p class="w3-center"><img src="<?php echo e(url('/img/avatar/avatar'.Auth::user()->id.'.jpg')); ?>" class="w3-circle" style="height:106px;width:106px" alt="avatar"></p>
         <form action="<?php echo e(url('user/avatar/upload')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

           <input type="file" name="file" id="file" class="w3-half" style="width: 57px;height: 25px;padding-top: 0px;padding-left: 0px;">
           <button type="submit" class="w3-button w3-blue w3-half w3-card pull-right" style="width: 57px;height: 25px;padding-top: 0px;padding-left: 0px;">Simpan</button>
         </form>
         <br>
         <hr>
         <?php if(Auth::user()->status == 'Mahasiswa'): ?>
         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i><?php echo e(Auth::user()->universitas->nama); ?></p>
         <p><i class="fa fa-home fa-fw w3-margin-right w3-text-theme"></i><?php echo e(Auth::user()->komunitas->nama_kota); ?></p>
         <p><i class="fa fa-birthday-cake fa-fw w3-margin-right w3-text-theme"></i><?php echo e(Auth::user()->tanggal_lahir); ?></p>
         <?php else: ?> 
         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i><?php echo e(Auth::user()->name); ?></p>
         <p><i class="fa fa-home fa-fw w3-margin-right w3-text-theme"></i><?php echo e(Auth::user()->kota->nama); ?></p>
         <p><i class="fa fa-birthday-cake fa-fw w3-margin-right w3-text-theme"></i><?php echo e(Auth::user()->created_at); ?></p>
         <?php endif; ?>
       </div>
     </div>
     <br>

     <!-- Accordion -->
     <div class="w3-card w3-round">
      <div class="w3-white">
        <a href="<?php echo e(url(Auth::user()->status.'/Solusi')); ?>"><button onclick="myFunction('Demo1')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-circle-o-notch fa-fw w3-margin-right"></i>Solusi</button></a>
        <a href="<?php echo e(url(Auth::user()->status.'/Ide')); ?>"><button onclick="myFunction('Demo2')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-calendar-check-o fa-fw w3-margin-right"></i>IDE & Karya</button></a>
        <a href="<?php echo e(url(Auth::user()->status.'/Relawan')); ?>"><button onclick="myFunction('Demo3')" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-users fa-fw w3-margin-right"></i>Relawan</button>
        </a>
        <!-- <div id="Demo3" class="w3-hide w3-container">
         <div class="w3-row-padding">
           <br>
           <div class="w3-half">
             <img src="/w3images/lights.jpg" style="width:100%" class="w3-margin-bottom">
           </div>
           <div class="w3-half">
             <img src="/w3images/nature.jpg" style="width:100%" class="w3-margin-bottom">
           </div>
           <div class="w3-half">
             <img src="/w3images/mountains.jpg" style="width:100%" class="w3-margin-bottom">
           </div>
           <div class="w3-half">
             <img src="/w3images/forest.jpg" style="width:100%" class="w3-margin-bottom">
           </div>
           <div class="w3-half">
             <img src="/w3images/nature.jpg" style="width:100%" class="w3-margin-bottom">
           </div>
           <div class="w3-half">
             <img src="/w3images/fjords.jpg" style="width:100%" class="w3-margin-bottom">
           </div>
         </div>
       </div> -->
     </div>      
   </div>
   <br>

   <!-- Interests --> 
<!--    <div class="w3-card w3-round w3-white w3-hide-small">
    <div class="w3-container">
      <p>Interests</p>
      <p>
        <span class="w3-tag w3-small w3-theme-d5">News</span>
        <span class="w3-tag w3-small w3-theme-d4">W3Schools</span>
        <span class="w3-tag w3-small w3-theme-d3">Labels</span>
        <span class="w3-tag w3-small w3-theme-d2">Games</span>
        <span class="w3-tag w3-small w3-theme-d1">Friends</span>
        <span class="w3-tag w3-small w3-theme">Games</span>
        <span class="w3-tag w3-small w3-theme-l1">Friends</span>
        <span class="w3-tag w3-small w3-theme-l2">Food</span>
        <span class="w3-tag w3-small w3-theme-l3">Design</span>
        <span class="w3-tag w3-small w3-theme-l4">Art</span>
        <span class="w3-tag w3-small w3-theme-l5">Photos</span>
      </p>
    </div>
  </div> -->
  <br>

  <!-- Alert Box -->
  <div class="w3-container w3-display-container w3-round w3-theme-l4 w3-border w3-theme-border w3-margin-bottom w3-hide-small">
    <!-- <span onclick="this.parentElement.style.display='none'" class="w3-button w3-theme-l3 w3-display-topright">
      <i class="fa fa-remove"></i>
    </span> -->
    <p><strong>Tentang Saya</strong></p>
    <p><?php echo e(Auth::user()->keterangan); ?></p>
  </div>

  <!-- End Left Column -->
</div>
<?php echo $__env->yieldContent('middle'); ?>

<!-- Right Column -->
<div class="w3-col m2">
  <!-- <div class="w3-card w3-round w3-white w3-center">
    <div class="w3-container">
      <p>Upcoming Events:</p>
      <img src="/w3images/forest.jpg" alt="Forest" style="width:100%;">
      <p><strong>Holiday</strong></p>
      <p>Friday 15:00</p>
      <p><button class="w3-button w3-block w3-theme-l4">Info</button></p>
    </div>
  </div>
  <br> -->
  <?php $i = 1; ?>
  <?php foreach($users as $u): ?>
  <?php if($u->status != 'Komunitas'): ?>
  <div class="w3-card w3-round w3-white w3-center">
    <div class="w3-container">
      <p><?php echo e($i++); ?></p>
      <img src="<?php echo e(url('img/avatar/avatar'.$u->id)); ?>.jpg" alt="Avatar" class="w3-circle" style="width:50%"><br>
      <span><?php echo e($u->name); ?></span>
      <div class="w3-row w3-opacity">
        <div class="w3-third">
          <button class="w3-button w3-block w3-green w3-section" title="Accept"><?php echo e($u->jumlah_solusi); ?></button>
        </div>
        <div class="w3-third">
          <button class="w3-button w3-block w3-red w3-section" title="Decline"><?php echo e($u->jumlah_relawan); ?></button>
        </div>
        <div class="w3-third">
          <button class="w3-button w3-block w3-red w3-section" title="Decline"><?php echo e($u->jumlah_ide); ?></button>
        </div>
      </div>
    </div>
  </div>
  <br>
  <?php endif; ?>
  <?php endforeach; ?>

  <!-- <div class="w3-card w3-round w3-white w3-padding-16 w3-center">
    <p>ADS</p>
  </div>
  <br>

  <div class="w3-card w3-round w3-white w3-padding-32 w3-center">
    <p><i class="fa fa-bug w3-xxlarge"></i></p>
  </div> -->

  <!-- End Right Column -->
</div>

<!-- End Grid -->
</div>


<!-- End Page Container -->
</div>
<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>