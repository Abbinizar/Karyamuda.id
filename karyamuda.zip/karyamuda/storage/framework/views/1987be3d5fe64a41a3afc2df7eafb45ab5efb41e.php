<?php $__env->startSection('middle'); ?>
<!-- Middle Column -->
<div class="w3-col m7">



  <?php foreach($data as $row): ?>
  <div class="w3-container w3-card w3-white w3-round w3-margin"><br>

    <span class="w3-right w3-opacity"><?php echo e($row->berita->tanggal); ?></span>
    <h4>Berita : <?php echo e($row->berita->user->kota->nama); ?></h4>
    <hr class="w3-clear">
    <p><?php echo e($row->berita->berita); ?></p>
  </div> 

  <div class="w3-container w3-card w3-white w3-round w3-margin"><br>
    <span class="w3-right w3-opacity"><?php echo e($row->tanggal); ?></span>
    <h4>Solusi : <?php echo e($row->user->name); ?></h4>
    <hr class="w3-clear">
    <p><?php echo e($row->solusi); ?></p>
    <div class="w3-col">
      <a href="<?php echo e(url(Auth::user()->status.'/Relawan/Join/'.$row->id_solusi)); ?>" class="w3-button w3-theme-d1 w3-margin-bottom w3-col">Join</a>
    </div>
  </div> 

  <?php foreach($row->relawan as $r): ?>
  <div style="width: 350px; margin-left: 5px;" class="w3-container w3-card w3-third w3-white w3-round w3-margin"><br>
    <h4><?php echo e($r->user->name); ?></h4>
    <hr class="w3-clear">
    <p>Tanggal Join : <?php echo e($r->tanggal); ?></p>
  </div> 
  <?php endforeach; ?>

  <?php endforeach; ?>
  <!-- End Middle Column -->
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>