<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Copyright &copy; 2017 <a href="#">ASA Mutiara Informa</a>.</strong> All rights reserved.
 </footer>