<?php $__env->startSection('body'); ?>
<!-- Navigation-->

<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?php echo e(url('/')); ?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Solusi</li>
    </ol>
    <!-- Icon Cards-->
    <div class="row">
      <div class="col-md-12">
        <i class="fa fa-newspaper-o"></i>Profil
      </div>
      <hr class="mt-4">
      <div class="col-md-12">
        <div class="card">
          <div class="card-footer small text-muted pull-right">Last Update <?php echo e(Auth::user()->updated_at); ?>

          </div>
          <hr class="my-2">
          <div class="card-body">
            <form action="<?php echo e(url('Mahasiswa/Update')); ?>" method="post" accept-charset="utf-8">
              <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Username</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="username" value="<?php echo e(Auth::user()->username); ?>" placeholder="">
                </div>
              </div>
              <div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Nama</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="name" value="<?php echo e(Auth::user()->name); ?>" placeholder="">
                </div>
              </div>
              <div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Email</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" placeholder="">
                </div>
              </div>
              <div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Universitas</label>
                </div>
                <div class="col-md-4">
                  <select name="id_universitas" class="form-control">
                    <?php foreach($universitas as $row): ?>
                    <?php if($row->id_universitas == Auth::user()->id_universitas): ?>
                    <option value="<?php echo e($row->id_universitas); ?>" selected><?php echo e($row->nama); ?></option>
                    <?php else: ?> 
                    <option value="<?php echo e($row->id_universitas); ?>"><?php echo e($row->nama); ?></option>
                    <?php endif; ?>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="row">
                <div class="col-md-2">
                  <label class="pull-right">NIM</label>
                </div>
                <div class="col-md-4">
                  <input type="text" name="nim" class="form-control" value="<?php echo e(Auth::user()->nim); ?>" placeholder="">
                </div>
              </div>
              <div class="row">
                <div class="col-md-2">
                  <label class="pull-right">No Hp</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="no_hp" value="<?php echo e(Auth::user()->no_hp); ?>" placeholder="">
                </div>
              </div>
              <div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Facebook</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="facebook" value="<?php echo e(Auth::user()->facebook); ?>" placeholder="">
                </div>
              </div><div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Twitter</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="twitter" value="<?php echo e(Auth::user()->twitter); ?>" placeholder="">
                </div>
              </div><div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Instagram</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="instagram" value="<?php echo e(Auth::user()->instagram); ?>" placeholder="">
                </div>
              </div><div class="row">
                <div class="col-md-2">
                  <label class="pull-right">Biografi</label>
                </div>
                <div class="col-md-4">
                  <textarea name="keterangan" rows="5" class="form-control"><?php echo e(Auth::user()->keterangan); ?></textarea>
                </div>
              </div>
              </div><div class="row">
                <div class="col-md-2">
                  <!-- <label class="pull-right">Simpan</label> -->
                </div>
                <div class="col-md-4">
                  <button type="submit" style="width: 325px; margin-left: 12px;" class="btn btn-primary">Simpan</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- /Card Columns-->
</div>
<!-- Example DataTables Card-->
<!-- /.container-fluid-->
<!-- /.content-wrapper-->
<footer class="sticky-footer">
  <div class="container">
    <div class="text-center">
      <small>Copyright © Your Website 2017</small>
    </div>
  </div>
</footer>
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fa fa-angle-up"></i>
</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>