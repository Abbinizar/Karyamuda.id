<?php $__env->startSection('middle'); ?>
<!-- Middle Column -->
<div class="w3-col m7">
  <?php if(Auth::user()->status != 'Komunitas'): ?>
  <?php foreach($data as $row): ?>
  <div class="w3-container w3-card w3-white w3-round w3-margin"><br>
    <span class="w3-right w3-opacity"><?php echo e($row->berita->tanggal); ?></span>
    <h4>Berita : <?php echo e($row->berita->user->kota->nama); ?></h4>
    <hr class="w3-clear">
    <p><?php echo e($row->berita->berita); ?></p>
  
    <span class="w3-right w3-opacity"><?php echo e($row->tanggal); ?></span>
    <h4>Solusi : <?php echo e($row->user->name); ?></h4>
    <hr class="w3-clear">
    <p><?php echo e($row->solusi); ?></p>
  </div> 
  <?php endforeach; ?>
  <?php else: ?> 
  <?php foreach($data as $row): ?>
  <div class="w3-container w3-card w3-white w3-round w3-margin"><br>
    <span class="w3-right w3-opacity"><?php echo e($row->tanggal); ?></span>
    <h4>Berita : <?php echo e($row->user->kota->nama); ?></h4>
    <hr class="w3-clear">
    <p><?php echo e($row->berita); ?></p>
    <?php foreach($row->solusi as $r): ?>
    <span class="w3-right w3-opacity"><?php echo e($r->tanggal); ?></span>
    <h4>Solusi : <?php echo e($r->user->name); ?></h4>
    <hr class="w3-clear">
    <p><?php echo e($r->solusi); ?></p>
    <?php endforeach; ?>
  </div> 
  <?php endforeach; ?>
  <?php endif; ?>
  <!-- End Middle Column -->
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.navbar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>