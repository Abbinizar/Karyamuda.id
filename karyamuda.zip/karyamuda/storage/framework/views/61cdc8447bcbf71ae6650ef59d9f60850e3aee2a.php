<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>KaryaMuda-Form Mahasiswa</title>
    <script src="<?php echo e(url('/jquery-3.2.1.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(url('css/style_isi.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <script src="<?php echo e(url('bootstrap/js/bootstrap.js')); ?>"></script>
    <meta name="viewport" content="width=device-width, initial-scale=10">
    <link href='logo.png' style="width: 32px;height: 32px;" rel='shortcut icon'>
</head>
<body>
    <div id="fmatas"></div>
    <div id="fmisi">
        <div id="fmisi_atas">
            <center><h2>Daftar Akun</h2></center>
            <div class="fmform" >
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-4 control-label">Name</label>

                        <div class="col-md-6">
                            <input id="name" style="width: 420px; margin-left: 0px;margin-top: 20px;" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                            <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                        <div class="col-md-6">
                            <input id="email" type="email" style="margin-top: 20px;" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                            <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-md-4 control-label">Password</label>

                        <div class="col-md-6">
                            <input id="password" type="password" style="margin-top: 20px;" class="form-control" name="password">

                            <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                        <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                        <div class="col-md-6">
                            <input id="password-confirm" type="password" style="margin-top: 20px;" class="form-control" name="password_confirmation">

                            <?php if($errors->has('password_confirmation')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                        <label for="password-confirm" class="col-md-4 control-label">Status</label>

                        <div class="col-md-6">
                            <select name="status" id="status" onclick="setData();" style="margin-top: 20px;" class="form-control">
                                <option value="Mahasiswa">Mahasiswa</option>
                                <option value="Komunitas">Komunitas</option>
                            </select>

                            <?php if($errors->has('status')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('id_komunitas') ? ' has-error' : ''); ?>" id="komunitas">
                        <label for="password-confirm" class="col-md-4 control-label">Komunitas</label>
                        <div class="col-md-6">
                            <select name="id_komunitas" id="id_komunitas" style="margin-top: 20px;" class="form-control">
                                option
                                <?php foreach($komunitas as $row): ?>
                                <option value="<?php echo e($row->id_user); ?>"><?php echo e($row->kota->nama); ?></option>}
                                <?php endforeach; ?>
                            </select>

                            <?php if($errors->has('id_komunitas')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('id_komunitas')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('id_kota') ? ' has-error' : ''); ?>" id="kota">
                        <label for="id_kota" class="col-md-4 control-label">Kota</label>
                        <div class="col-md-6">
                            <select name="id_kota" id="id_kota" style="margin-top: 20px;" class="form-control">
                                <?php foreach($kota as $row): ?>
                                <option value="<?php echo e($row->id_kota); ?>"><?php echo e($row->nama); ?></option>}
                                <?php endforeach; ?>
                            </select>

                            <?php if($errors->has('id_kota')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('id_kota')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('id_universitas') ? ' has-error' : ''); ?>" id="universitas">
                        <label for="id_universitas" class="col-md-4 control-label">Universitas</label>
                        <div class="col-md-6">
                            <select name="id_universitas" id="id_universitas" style="margin-top: 20px;" class="form-control">
                                <?php foreach($universitas as $row): ?>
                                <option value="<?php echo e($row->id_universitas); ?>"><?php echo e($row->nama); ?></option>}
                                <?php endforeach; ?>
                            </select>

                            <?php if($errors->has('id_universitas')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('id_universitas')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-btn fa-user"></i> Register
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            setData();
        })
        function setData(){
            var a = $('#status').val();
            if (a == 'Mahasiswa') {
                $('#komunitas').show();
                $('#universitas').show();
                $('#kota').hide();
            }else{
                $('#komunitas').hide();
                $('#universitas').hide();
                $('#kota').show();
            }
        }
    </script>


</body>
</html> 