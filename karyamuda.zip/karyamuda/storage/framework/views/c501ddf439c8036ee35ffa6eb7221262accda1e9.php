<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>RSU Bakti Mulia</title>
  <link rel="icon" type="image/png" href="<?php echo e(url('assets/ico/logo.png')); ?>">`
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="<?php echo e(url('../bootstrap/css/bootstrap.min.css')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('../assets/font-awesome/css/font-awesome.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/font-awesome/css/font-awesome.min.css')); ?>">
  <meta name="csrf-token" content="<?php echo e(Session::token()); ?>"> 
  <!-- Ionicons -->
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css"> -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(url('/dist/css/AdminLTE.min.css')); ?>">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
      folder instead of downloading all of them to reduce the load. -->
      <link rel="stylesheet" href="<?php echo e(url('/dist/css/skins/_all-skins.min.css')); ?>">
      <!-- iCheck -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/iCheck/all.css')); ?>">
      <!-- Morris chart -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/morris/morris.css')); ?>">
      <!-- jvectormap -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/jvectormap/jquery-jvectormap-1.2.2.css')); ?>">
      <!-- Date Picker -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/datepicker/datepicker3.css')); ?>">
      <!-- Daterange picker -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/daterangepicker/daterangepicker-bs3.css')); ?>">
      <!-- bootstrap wysihtml5 - text editor -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">
      <!-- CKEDITOR -->
      <!-- Date Time Picker -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css')); ?>">
      <!-- DataTables -->
      <link rel="stylesheet" href="<?php echo e(url('/plugins/datatables/dataTables.bootstrap.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(url('ok/css/animate.css')); ?>">
      <script src="<?php echo e(url('/assets/js/jQuery-2.1.4.min.js')); ?>"></script>
    </head>
    <body class="hold-transition skin-green-light fixed sidebar-mini">
      <?php echo $__env->yieldContent('content'); ?>
      

    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo e(url('/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!-- moment js -->
    <script src="<?php echo e(url('/plugins/moment-develop/min/moment.min.js')); ?>"></script>
    <!-- datepicker -->
    <script src="<?php echo e(url('/plugins/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script type="text/javascript">
      
    </script>
    <!-- Date Time Picker -->
    <script type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(url('/assets/js/app.min.js')); ?>"></script>
    <!-- Searching -->
    <script type="text/javascript" async="" src="<?php echo e(url('../assets/js/search.js')); ?>"></script>
    <!-- zebra date -->
    <script src="<?php echo e(url('/plugins/Zebra_Datepicker-master/public/javascript/zebra_datepicker.js')); ?>" type="text/javascript"></script>
    <link href="<?php echo e(url('/plugins/Zebra_Datepicker-master/public/css/metallic.css')); ?>" rel="stylesheet" type="text/css">
    <!-- datatables -->
    <!-- daterange -->
    <script src="<?php echo e(url('/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
        <!-- DataTables -->
    <script src="<?php echo e(url('/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('/plugins/iCheck/icheck.min.js')); ?>"></script>
    <script src="<?php echo e(url('/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <!-- <script src="<?php echo e(url('/ok/js/wow.min.js')); ?>"> -->

    </script>
    <script>
      // new WOW().init();
    </script>
    <script>
     //iCheck for checkbox and radio inputs
     $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });
    // $('.sidebar ul li').hover(function() {
    //   $(this).children('ul').stop(true, false, true).slideToggle(300);
    // });
  </script>
</body>  
</html>